import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.css']
})
export class ContactsComponent implements OnInit {

  contactForm = new FormGroup({
    name: new FormControl(''),
    phoneNumber: new FormControl(''),
    address: new FormGroup({
      street: new FormControl(''),
      city: new FormControl(''),
      state: new FormControl('')
    }),
    email: new FormControl(''),
    dob: new FormControl('')
  })

  onSubmit(){
    console.log("a")
    console.warn(this.contactForm.value);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
