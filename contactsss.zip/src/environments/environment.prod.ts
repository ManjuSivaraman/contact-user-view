export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyDMsEtcF5W4D4ZTI0bdfvqdyB91wICEhYE",
    authDomain: "admin-6329e.firebaseapp.com",
    databaseURL: "https://admin-6329e.firebaseio.com",
    projectId: "admin-6329e",
    storageBucket: "admin-6329e.appspot.com",
    messagingSenderId: "124748011902",
    appId: "1:124748011902:web:9783cca1ebab6d01b1bb2f",
    measurementId: "G-ELLVXN8ZQS"
  }
};